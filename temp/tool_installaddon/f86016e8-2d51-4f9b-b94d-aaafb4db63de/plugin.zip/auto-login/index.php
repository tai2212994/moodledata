<?php
    require ('../config.php');
        $PAGE->set_title($SITE->fullname);
        $PAGE->set_heading($SITE->fullname);
        echo $OUTPUT->header();

        $url = $PAGE->url;

        $parts = parse_url($url);
        parse_str($parts['query'], $query);
        //echo $query['key'];
        $user = $DB->get_record('user',array('username'=>$query['key']));
        if ($user) {
            complete_user_login($user);

            \core\session\manager::apply_concurrent_login_limit($user->id, session_id());
            redirect("$CFG->wwwroot/");
        }
        echo $OUTPUT->box_end();
        echo $OUTPUT->footer();


